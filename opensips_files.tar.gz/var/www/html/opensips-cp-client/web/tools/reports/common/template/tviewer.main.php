<?php
 /*
 * Copyright (C) 2011 OpenSIPS Project
 *
 * This file is part of opensips-cp, a free Web Control Panel Application for 
 * OpenSIPS SIP server.
 *
 * opensips-cp is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * opensips-cp is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */


// load table content

global $link_general;
global $link;

$exportfile = 'upload/stats-'.rand(10000,10000000).'.csv';
$export_delimiter = ';';
$condition_array = array();
$filters_array = array();
$groupby_array = array();
$carrier_array = get_carriers();
$client_array  = get_clients();
$range_array = get_ranges();
//var_dump($_POST);
//var_dump($range_array);

$start_time = '00:00';
$end_time = '23:59';
$groupby = 'client_id';

extract($_POST);
$filter_client = $_SESSION['client_id'];
//echo $period,$start_date,$end_date,$start_time,$end_time;
if ($bycarriers == 'on') $bycarriers = 'checked';
if ($byranges   == 'on') $byranges   = 'checked';
$byclients  = 'checked';
if ($bycountry  == 'on') $bycountry  = 'checked';


echo '<form id=mainsearch method=POST>';
echo '<fieldset id=groupby name=groupby value=groupby><legend>Period:</legend>';
echo '<input type="date" name=start_date value='.$start_date.' ><input type="time" name=start_time value='.$start_time.'>';
echo ' BETWEEN <input type="date" name=end_date value='.$end_date.' ><input type="time" name=end_time value='.$end_time.' > <br>';
echo '</fieldset><br>';
echo '<fieldset name=fileterby value=filterby><legend>Filters:</legend>';
echo 'Country:&nbsp;<input type=text name=filter_country value='.$filter_country.'><br>';
echo 'Carrier:&nbsp;&nbsp;&nbsp;<input type=text name=filter_carrier value='.$filter_carrier.'><br>';
echo 'Range:&nbsp;&nbsp;&nbsp;<input type=text name=filter_range value='.$filter_range.'><br>';
//echo 'Client:&nbsp;&nbsp;&nbsp;&nbsp;<input type=text name=filter_client value='.$filter_client.'>';
//echo 'Client:&nbsp;&nbsp;&nbsp;&nbsp;<input type=hidden name=filter_client value="1">';
echo '</fieldset><br>';
echo '<input type=hidden name=period value=set >';
echo '<input type=hidden name=exportfile value='.$exportfile.' >';
echo '<fieldset id=groupby name=groupby value=groupby><legend>Group by:</legend>';
echo '<input type=checkbox name=bycarriers '.$bycarriers.'>Carriers';
echo '<input type=checkbox name=byclients '.$byclients.'>Clients';
echo '<input type=checkbox name=byranges '.$byranges.'>Ranges';
echo '<input type=checkbox name=bycountry '.$bycountry.'>Country';
echo '</fieldset>';
echo '<input type=submit class=searchButton >';
echo '<input type=submit class=searchButton name=action value=Export formaction="custom_export.php">';
echo '</form>';

//echo '<form  method=POST target=_blank>';
//echo '<input type=submit class=searchButton name=action value=show formaction=../../system/cdrviewer/cdrviewer.php formid=mainsearch>';
//echo '</form>';



//Set conditions for search
if ($start_date && $start_time)
    $condition_array[] = "time > '$start_date $start_time'";

if ($end_date && $end_time)
    $condition_array[] = "time < '$end_date $end_time'";


$condition = implode(" and ", $condition_array);
if (empty($condition)) $condition = "(1=1)";
//

//set group by for search
if ($byranges)      $groupby_array[] = 'range_id';
if ($bycountry)     $groupby_array[] = 'country';
if ($byclients)     $groupby_array[] = 'client_id';
if ($bycarriers)    $groupby_array[] = 'carrier_id';
$groupby                 = implode(",", $groupby_array);
if ($groupby) $groupby   = "group by ".$groupby;
//

//set filters
if ($filter_country) $filters_array[] = "country like '%$filter_country%'";

if ($filter_carrier) {
    $carriers_array = get_carriers($filter_carrier);
    $filter_carrier = implode(',',$carriers_array);
    $filters_array[] = "carrier_id in ($filter_carrier)";
}

if ($filter_range)  {
    $ranges_array = get_ranges($filter_range);
    $filter_range = implode(',',$ranges_array);
    $filters_array[] = "range_id in ($filter_range)";
}
if ($filter_client) {
 //   $clients_array = get_clients($filter_client);
   // $filter_client = implode(',',$clients_array);
    $filters_array[] = "client_id = '$filter_client'";
}
//

if (count($filters_array) == 1) $condition .= " and ";
    $condition .= implode(" and ", $filters_array);
//

//set order by search
$order_column = "sumclient";
$order_type = "asc";
$order = "$order_column $order_type";
//

$sql  = "SELECT client_id, carrier_id, range_id, country, count(*) as calls, sum(duration)/60 as minutes, ROUND(sum(carrier_payout),4) as sumcarrier, ROUND(sum(client_payout),4) as sumclient 
         from acc
         where (1=1) and $condition 
         $groupby  
         order by $order";

//echo $sql."<br>";
$query_all = $link->query($sql);

$mytable = new Table();
$mytable->start('class="ttable" width="95%" cellspacing="2" cellpadding="2" border="0"');

$headers = array_merge($groupby_array,array('calls','minutes','sumcarrier','sumclient','cdrs'));
$aggregate_headers = array('calls','minutes','sumcarrier','sumclient'); //headers to be aggragated and added to end of table

$mytable->th_array($headers);

//prepare export headers
$csv_export = array();
$csv_headers = $headers;
$csv_headers = array_slice($csv_headers,0,-1);
$csv_export[] = implode($export_delimiter,$csv_headers);
//
//var_dump($headers);

while ($res = $query_all->fetch()) {

    //foreach($res as $key => $value) {}
    //$csv_export .= implode(",",array_values($res));
    //$csv_export .= "<br>";
    //}
    
    $params_array = array ();

    $mytable->tr_start();
    
    $csv_row = array();
    
    foreach ($headers as $header) {
        
        
        switch ($header) {
            
            case 'cdrs':

                //$mytable->td('<input type=submit name=action value=getcdrs formaction="../../system/cdrviewer/cdrviewer.php" form="cdrsearch">',"align=center");
                foreach($params_array as $key => $value) {
                    
                    $params .= $key."=".$value."&";
                }
                $mytable->td('<a href="../../system/cdrviewer/cdrviewer.php?action=getcdrs&'.$params.'">cdrs</a>',"align=center");
                $params_array = array();
                break;
            
            case 'range_id':
                
                $range = array_search ($res[$header], $range_array);
                $mytable->td($range,"align=right");
                $params_array[$header] = $res[$header];
                $csv_row[] = $range;
                break;
            case 'carrier_id':
                $carrier = array_search ($res[$header], $carrier_array);
                $mytable->td($carrier,"align=right");
                $params_array[$header] = $res[$header];
                $csv_row[] = $carrier;
                break;
            case 'client_id':
                $client = array_search ($res[$header], $client_array);
                $mytable->td($client,"align=right");
                $params_array[$header] = $res[$header];
                $csv_row[] = $client;
                break;

            default:
                $csv_row[] = $res[$header];
                if (in_array($header, $aggregate_headers)) {
                    $aggregate[$header] = $aggregate[$header] + $res[$header];
                    //echo 
                }

                $mytable->td($res[$header],"align=right");
                //$params_array[$header] = $res[$header];
        }

    }

    $csv_export[] = implode($export_delimiter,$csv_row);
}
//add summs row
$mytable->tr_start();
$i = 0;
$csv_array = array();

foreach ($headers as $header) {
    $i++;        
    $out = '';

    if ($i == 1 )
         $out = 'Totals';
        
    if (in_array($header, $aggregate_headers))
        $out = $aggregate[$header];

    $csv_array[] = $out;
    $mytable->td($out,'style="font-weight: bold;"');   
    
}

$mytable->tr_end();
//
$mytable->end();

$csv_export[] = implode($export_delimiter,$csv_array);

//var_dump($csv_export);

$content = implode("\n",$csv_export);
file_put_contents($exportfile, $content);

?>