<?php
require('lib/functions.inc.php');

//var_dump($_POST);
extract($_POST);

if ($action == 'Export') {
    file_force_download($exportfile);
}

?>
