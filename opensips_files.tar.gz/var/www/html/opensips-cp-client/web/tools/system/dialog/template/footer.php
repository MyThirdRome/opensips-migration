  </td>
 </tr>
</table>
</center>
</body>

</html>
<?php
 $_SESSION['user_active_tool']="dialog";
 $_SESSION['user_active_page']=$page_name;
?>
