  </td>
 </tr>
</table>
</center>
</body>

</html>
<?php
 $_SESSION['user_active_tool']="loadbalancer";
 $_SESSION['user_active_page']=$page_name;
?>
