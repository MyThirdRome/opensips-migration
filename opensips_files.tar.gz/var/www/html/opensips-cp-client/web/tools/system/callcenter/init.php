<?php
//use this file to point to the config file of this module 
//this file is used in lib/data_loader.php and in template/header.php but also index.php
$branch = "system";
$module_id = "callcenter";
?>
