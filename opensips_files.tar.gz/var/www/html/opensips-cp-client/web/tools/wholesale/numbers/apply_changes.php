<?php
/*
* Copyright (C) 2011 OpenSIPS Project
*
* This file is part of opensips-cp, a free Web Control Panel Application for
* OpenSIPS SIP server.
*
* opensips-cp is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* opensips-cp is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

?>
<?php
session_start();
require("init.php");

require_once("../../../../config/tools/".$branch."/".$module_id."/local.inc.php");
require("../../../common/mi_comm.php");
require("../../../common/cfg_comm.php");
require("lib/functions.inc.php");

require_once("../../../../config/db.inc.php");
require_once("lib/functions.inc.php");
require_once("lib/db_connect.php");


$command=$custom_config[$module_id][$_SESSION[$module_id]['submenu_item_id']]['custom_mi_command'];

?>
<fieldset><legend>Sending MI command: <?=$command?></legend>
<br>
<?php

/*$mi_connectors=get_all_proxys_by_assoc_id($talk_to_this_assoc_id);

for ($i=0;$i<count($mi_connectors);$i++){
	echo "Sending to <b>".$mi_connectors[$i]."</b> : ";

	$message=mi_command($command, NULL, $mi_connectors[$i], $errors);

	if (empty($errors)) {
		echo "<font color='green'><b>Success</b></font>";
	}
	echo "<br>";
}*/
//move DB data to Redis

$dsn = 'mysql:host=' . $config->db_host . ';dbname=General';
try {
        $link = new PDO($dsn,"web", "webpassword123");
} catch (PDOException $e) {
        error_log(print_r("Failed to connect to: ".$dsn, true));
        print "Error!: " . $e->getMessage() . "<br/>";
        die;
}



require 'vendor/autoload.php';
Predis\Autoloader::register();

$client = new Predis\Client('tcp://127.0.0.1:6379');
$client->select('0'); 
$client->flushdb();


//move numbers
//HMSET number_123 number_id "10" range_id "1" carrier_payout "0.2" client_payout "0.3" client_id "1"

$nums = $link->query("SELECT id,number,range_id,carrier_payout,client_payout,client_id,Country from numbers");
	
while ($res = $nums->fetch()) {
	$client->hmset(
				"number_".$res['number'],
				"number_id",$res['id'],
				"range_id",$res['range_id'],
				"carrier_payout",$res['carrier_payout'],
				"client_payout",$res['client_payout'],
				"client_id",$res['client_id'],
				"country",$res['Country']
		);
}
    //var_dump($res);

//move clients IPs
$clients_ip = $link->query("SELECT client_id,ip,port from clients_ips where enabled = true");
//HMSET client_ip 1 188.120.255.242	
while ($res = $clients_ip->fetch()) {
	$client->hmset("client_ip",$res['client_id'],$res['ip'].":".$res['port']);
}

//move carriers IPs
$carriers_ip = $link->query("SELECT carrier_id,ip,port from carriers_ips where enabled = true");
//HMSET client_ip 1 188.120.255.242	
while ($res = $carriers_ip->fetch()) {
	$client->hmset("carrier_ip",$res['ip'],$res['carrier_id']);
}

echo "<font color='green'><b>Success</b></font>";
?>

</fieldset>
