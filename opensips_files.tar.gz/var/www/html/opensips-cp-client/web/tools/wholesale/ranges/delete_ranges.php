<?php

require("init.php");
include("lib/db_connect.php");

$dsn = 'mysql:host=' . $config->db_host . ';dbname=General';
try {
        $link = new PDO($dsn,"web", "webpassword123");
} catch (PDOException $e) {
        error_log(print_r("Failed to connect to: ".$dsn, true));
        print "Error!: " . $e->getMessage() . "<br/>";
        die;
}

//var_dump($_GET);
$array_ranges = implode(",",array_values($_GET));


$sth = $link->prepare("DELETE from ranges where id in ($array_ranges)");
$sth->execute();
echo "Ranges deleted, press BACK on browser";

?>