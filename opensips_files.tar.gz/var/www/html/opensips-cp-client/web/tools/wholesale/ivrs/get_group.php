<?php
    extract($_GET);
    include("init.php");
    include("lib/db_connect.php");
    $ivr_array = array();

    //global $link_general;
    //check group_id for number
    $group_query = $link_general->prepare("SELECT ivr_group from numbers where number = ? limit 1");
    $group_query->execute(array($number));
    $res_group = $group_query->fetch();
    $ivr_group = $res_group['ivr_group'];
    
    $ivrname_query = $link_general->query("select filename from ivrs where group_id = $ivr_group");
    $i = 0;
    
    while ($res_ivr = $ivrname_query->fetch()){
        $i++;
        $ivr_array[] = substr($res_ivr['filename'],0,-4);
    }
    $r = rand(0,$i-1);
    echo $ivr_array[$r];
        
    //var_dump($_GET);
?>