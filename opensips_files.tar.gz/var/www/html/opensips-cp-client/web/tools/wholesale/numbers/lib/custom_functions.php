<?php

function get_range_by_name($range_name) {
    global $link;
    //echo $range_name;
    $range = $link->query("SELECT id,range_name from ranges where range_name = '$range_name' LIMIT 1");
    $res = $range->fetch();
    //var_dump($res);
    
    if ($res['id']) { 
      return $res['id'];
    } else {
    
    return 0;
    }
  }
  
  function add_range($range_array) {
    global $link;
  
  /* 
  $range = array(
  ':range_name'       => 'a',
  ':carrier_id'       => '1',
  ':carrier_payout'   => '0.1',
  ':carrier_pay_term' => '30/30',
  ':client_payout'    => '0.2',
  ':Country'          => 'TempCountry'
  );
  
  */
  
  $range = $link->prepare("INSERT INTO ranges (range_name,carrier_id,carrier_payout,carrier_pay_term,client_payout,Country) 
    VALUES (:range_name,:carrier_id,:carrier_payout,:carrier_pay_term,:client_payout,:Country)");
  
  $range->execute($range_array);
  
    return $link->lastInsertId();  
  
  }

function get_range_id() {
    global $link;
}


function get_carrier_id_by_name($carrier_name) {
    global $link;
  
    $range = $link->query("SELECT id,name from carriers where name = '$carrier_name' LIMIT 1");
    $res = $range->fetch();
    //var_dump($res);
    
    if ($res['id']) { 
      return $res['id'];
    } else {
    
    return 0;
    }

}

function add_carrier($carrier) {
    global $link;

 
  $query = $link->query("INSERT INTO carriers (name) 
                          VALUES ('$carrier')");

    return $link->lastInsertId();  
    
}
    

function custom_save_numbers_to_file() {
global $custom_config;
global $link;
global $module_id;
global $_SESSION;
global $where;
global $qvalues;
$columns = array("range_name","country","number","carrier","carrier_payout","carrier_pay_term","client_payout","notes");

//$a = implode(",",array_keys($custom_config[$module_id][$_SESSION[$module_id]['submenu_item_id']]['custom_table_column_defs']));
//var_dump($custom_config);

$random=rand(1000,999999);
    $filename = "/var/www/html/opensips-cp/web/uploads/numbers-$random.csv";
    
    $query_csv = "select ".implode(',',$columns)." 
	INTO OUTFILE '$filename' FIELDS TERMINATED BY ';' 
	from ".$custom_config[$module_id][$_SESSION[$module_id]['submenu_item_id']]['custom_table']." 
	where ".$where." 
	order by ".$custom_config[$module_id][$_SESSION[$module_id]['submenu_item_id']]['custom_table_order_by'];
    
	$stm_csv = $link->prepare($query_csv);
    if($stm_csv->execute($qvalues) === false) {
	die('Failed to issue query, error message : ' . print_r($stm_csv->errorInfo(), true). "[".$query_csv."]");
    }

    if (!file_exists($filename)) echo "No file $filename send this error to admin<br>";
    return $filename;
}

?>