<?php

$uploaddir = '/var/lib/asterisk/sounds/en/';
$uploadfile = $uploaddir . basename($_FILES['filename']['name']);
//move_uploaded_file($_FILES['filename']['tmp_name'], $uploadfile);

echo '<pre>';
if (move_uploaded_file($_FILES['filename']['tmp_name'], $uploadfile)) {
    echo "Файл корректен и был успешно загружен.\n";
    var_dump($_POST);
} else {
  echo "Возможная атака с помощью файловой загрузки!\n";
  echo $uploadfile;
  var_dump($_POST);
}

echo 'Некоторая отладочная информация:';
print_r($_FILES);

print "</pre>";
?>