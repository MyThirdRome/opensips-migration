<?php

#################
# start details	#
#################
if ($action=="import")
{

#		extract($_POST);
#		foreach ($custom_config[$module_id][$_SESSION[$module_id]['submenu_item_id']]['custom_table_column_defs'] as $key => $value)
#			$_SESSION[$key] = $_POST[$key];

echo '
<!-- Тип кодирования данных, enctype, ДОЛЖЕН БЫТЬ указан ИМЕННО так -->
<form enctype="multipart/form-data" action="custom_import.php" method="POST">
    <!-- Поле MAX_FILE_SIZE должно быть указано до поля загрузки файла -->
    <input type="hidden" name="MAX_FILE_SIZE" value="3000000" />
    <!-- Название элемента input определяет имя в массиве $_FILES -->
    Choose CSV file <input name="userfile" type="file" />
    <input type="submit" value="Import_add" />
</form>';


#		require("template/".$page_id.".details.php");
		require("template/footer.php");
		exit();
}

#############
# end details	#
#############

?>
