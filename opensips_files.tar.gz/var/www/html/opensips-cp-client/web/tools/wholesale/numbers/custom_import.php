<?php
/*
 * Copyright (C) 2011 OpenSIPS Project
 *
 * This file is part of opensips-cp, a free Web Control Panel Application for 
 * OpenSIPS SIP server.
 *
 * opensips-cp is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * opensips-cp is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
include "lib/custom_functions.php";


$uploaddir = '/var/www/html/opensips-cp/web/uploads/';
$uploadfile = $uploaddir . basename($_FILES['userfile']['name']);
if (!move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile)) {

    echo "<pre>";
    echo "Wrong send this info to your administrator<br>";
    print_r($_FILES);
    echo "</pre>";
    exit;
}


require("init.php");
include("lib/db_connect.php");

$dsn = 'mysql:host=' . $config->db_host . ';dbname=General';
try {
        $link = new PDO($dsn,"web", "webpassword123");
} catch (PDOException $e) {
        error_log(print_r("Failed to connect to: ".$dsn, true));
        print "Error!: " . $e->getMessage() . "<br/>";
        die;
}

//Range	Country	Number	Carrier 	Carrier Payout	Carrier Payterm	Client Payout	Remarks

$columns_count = 8;
if (($handle = fopen($uploadfile, "r")) !== FALSE) {
#    while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
    $data = fgetcsv($handle, 1000, ";");
        $num = count($data);
	if ($num != $columns_count) {
	    echo "Your csv file have wrong columns count. should be $columns_count but have $num";
	    exit;
	};

	while (($data = fgetcsv($handle, 1000, ";")) !== FALSE) {
#	echo print_r($data)."<br>";
	$range_name 			= $data[0];
	$range_country	 		= $data[1];
	$range_carrier_payout 	= $data[4];
	$range_carrier_payterm 	= $data[5];
	$range_client_payout 	= $data[6];
	$number 			 	= $data[2];
	$carrier 			 	= $data[3];
	
	//add carrier if not exist
	$carrier_id				= get_carrier_id_by_name($carrier);
	
	if ($carrier_id == 0) {
		
		$carrier_id = add_carrier($carrier);
		echo "Added $carrier with ID: $carrier_id<br>";
	}
	$data[9] = $carrier_id;

	//Add range if not present
	$range_id = get_range_by_name($range_name);
	
	if ($range_id == 0) {
		$range = array(
				':range_name'       => $range_name,
				':carrier_id'       => $carrier_id,
				':carrier_payout'   => $range_carrier_payout,
				':carrier_pay_term' => $range_carrier_payterm,
				':client_payout'    => $range_client_payout,
				':Country'          => $range_country
				  
		);
		$range_id = add_range($range);
		
		
	}
	
	$data[8] = $range_id;
	


	//carrier checking
	
	
	
	//if ($carrier == '') $info .= "$number - empty carrier\n<br>";
	//if ($carriers[$carrier] == "") $info .= "$number, $carrier have not ID\n<br>";
	
	$stmt = $link->prepare("insert ignore into numbers 
				(range_name,country,number,carrier, carrier_payout,carrier_pay_term,client_payout,notes,range_id,carrier_id) 
				values (?,?,?,?,?,?,?,?,?,?);");
#	$data[] = $carriers[$carrier];

	if (!$stmt->execute($data)) {
    	    print_r("Failed to fetch credentials!");
    	    error_log(print_r($stmt->errorInfo(), true));
    	    die;
	}

    

    }
#    print_r($data);

#    }
}
echo $info;
echo "OK";
?>
