<?php

require("init.php");
require("template/header.php");
include("lib/db_connect.php");

$dsn = 'mysql:host=' . $config->db_host . ';dbname=General';
try {
        $link = new PDO($dsn,"web", "webpassword123");
} catch (PDOException $e) {
        error_log(print_r("Failed to connect to: ".$dsn, true));
        print "Error!: " . $e->getMessage() . "<br/>";
        die;
}

//Dissalocate
if ($_GET['Disallocate']) { //allocates numbers to client
        //var_dump($_GET);
        $client_id = $_GET['Clients'];
        $array_ranges = implode(",",array_splice(array_values($_GET),1));
        $sql = "UPDATE numbers set client_id = '0' where id in ($array_ranges)";
        $sth = $link->query($sql);
        $operation = $_GET['Disallocate'];
        
}

//set price for selected numbers
if($_GET['set_carrier_payout'] && $_GET['set_client_payout']){

        $carrier_payout = $_GET['set_carrier_payout'];
        $client_payout = $_GET['set_client_payout'];
        $array_ranges = implode(",",array_splice(array_values($_GET),2));
        $sql = "UPDATE numbers set carrier_payout = '$carrier_payout',client_payout = '$client_payout' where id in ($array_ranges)";
        $sth = $link->query($sql);
        //echo $sql;
        $operation = "Set prices";
}

//choose price for numebers
if($_GET['Setprice']){
        $array_ranges = implode(",",array_splice(array_values($_GET),1));
        
        echo '<form method=GET>';
        echo "Set carrier_payout:";
        echo "<input  type=text name=set_carrier_payout>";
        echo "Set client_payout:";
        echo "<input  type=text name=set_client_payout>";
        echo "<input class=formButton type=submit> <br>";
        

        echo "Selected numbers:<br>";
        $sth = $link->query("SELECT id,number,carrier_payout,client_payout from numbers where id in ($array_ranges)");
        
        while ($client = $sth->fetch()) {
                $i++;
                
                $h = "<input type=hidden name=num_".$i." value=".$client['id'].">";
               // echo "<tr><td>$h".$client['number']."</td><td>".$client['carrier_payout']."</td><td>".$client['client_payout']."</td></tr><br>";
               echo "Number: $h ".$client['number']." carrier_payout: ".$client['carrier_payout']." client_payout: ".$client['client_payout']."<br>";
        }
        
        echo "</form><br>";
        
}

//allocates numbers to client
if ($_GET['Clients']) { //allocates numbers to client
        //var_dump($_GET);
        $client_id = $_GET['Clients'];
        $array_ranges = implode(",",array_splice(array_values($_GET),1));
        $sql = "UPDATE numbers set client_id = '$client_id' where id in ($array_ranges)";
        $sth = $link->query($sql);
        $operation = "Allocate";
        
}
//allocate numbers to ivrgruops
if ($_GET['ivrgroup']) { //allocates numbers to client
       
        $group_id = $_GET['ivrgroup'];
        $array_ranges = implode(",",array_splice(array_values($_GET),1));
        $sql = "UPDATE numbers set ivr_group = '$group_id' where id in ($array_ranges)";
        $sth = $link->query($sql);
        check_query($link);
        $operation = "IVR Allocate";
        
}

//choose client for allocating
if ($_GET['AllocateClient'])  { //choose client for allocating
        
        $array_ranges = implode(",",array_splice(array_values($_GET),1));
        //echo $array_ranges;
        
        echo '<form method="GET">';
        echo "<b>Choose client: </b>";
        echo '<select id="clients" name="Clients" class="dataselect" style="font-size: 16px;">';
        $sth = $link->query("SELECT id,name, company_name from clients");
        while ($client = $sth->fetch()) {
                echo "<option  value=".$client['id'].">".$client['name']."</option>";
        }

        echo '</select>';
        echo '<input class=formButton type=submit>';
        echo '<br>Numbers list:<br>';
        $sth = $link->query("SELECT id,number from numbers where id in ($array_ranges)");
        while ($numbers = $sth->fetch()) {
                $i++;
                echo "<input type=hidden name=num_".$i." value=".$numbers['id'].">";
                echo $numbers['number']."<br>";
        }

                
        
        echo '</form>';

}

//choose for allocating to IVR group

if ($_GET['AllocateIvr'])  { //choose client for allocating
        $array_ivrgroups = get_ivrgroups();
        $array_ranges = implode(",",array_splice(array_values($_GET),1));
        //echo $array_ranges;
        //var_dump($array_ivrgroups);
        
        echo '<form method="GET">';
        echo "<b>Choose IVR GROUP: </b>";
        echo '<select id="ivrgroups" name="ivrgroup" class="dataselect" style="font-size: 16px;">';
        /*
        $sth = $link->query("SELECT id,name, company_name from clients");
        while ($client = $sth->fetch()) {
                echo "<option  value=".$client['id'].">".$client['name']."</option>";
        }
        */
        foreach ($array_ivrgroups as $key => $value) {
                echo "<option  value=".$key.">".$value."</option>";
        }
        
        echo '</select>';
        echo '<input class=formButton type=submit>';
        echo '<br>Numbers list:<br>';

        $sth = $link->query("SELECT id,number from numbers where id in ($array_ranges)");
        check_query($link);
        while ($numbers = $sth->fetch()) {
                $i++;
                echo "<input type=hidden name=num_".$i." value=".$numbers['id'].">";
                echo $numbers['number']."<br>";
        }

                
        
        echo '</form>';

}


//allocates numbers to client
if ($_GET['Delete']) { //allocates numbers to client
        //var_dump($_GET);
        
        $array_ranges = implode(",",array_splice(array_values($_GET),1));
        $sql = "DELETE from numbers where id in ($array_ranges)";
        $sth = $link->query($sql);
        $operation = "Delete";
        
}
//var_dump($_GET);

if ($operation)
echo "<a class=\"searchButton\" href=\"index.php\">$operation Success. Back to prevision page.</a>";

require("template/footer.php");
//$sth = $link->prepare("DELETE from ranges where id in ($array_ranges)");
//$sth->execute();
//echo "Ranges deleted, press BACK on browser";

?>